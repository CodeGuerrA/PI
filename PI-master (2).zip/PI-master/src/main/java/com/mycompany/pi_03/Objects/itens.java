package com.mycompany.pi_03.Objects;

public class itens {
    private String nome;
    private double Valor;
    
}